# 🌶 SAKECE – Toko Sambal Online

Website toko online **SAKECE** yang siap deploy ke GitHub Pages. Tidak butuh backend, database, atau server. Order otomatis dikirim via WhatsApp.

---

## 📁 Struktur File

```
toko-online/
├── index.html        ← Halaman utama
├── css/
│   └── style.css     ← Semua styling
├── js/
│   └── main.js       ← Logika checkout & interaksi
├── images/
│   ├── sekece.jpeg   ← Background hero
│   ├── level1.jpeg   ← Foto produk Level 1
│   └── level2.jpeg   ← Foto produk Level 2
└── README.md
```

---

## 🚀 Cara Deploy ke GitHub Pages

### Langkah 1 – Buat Repository
1. Buka [github.com](https://github.com) → login
2. Klik tombol **"New"** (repository baru)
3. Beri nama repo, contoh: `sakece-web`
4. Set ke **Public**
5. Klik **"Create repository"**

### Langkah 2 – Upload File
1. Di halaman repo yang baru dibuat, klik **"uploading an existing file"**
2. Drag & drop **semua file dan folder** dari folder `toko-online/` ini
3. Klik **"Commit changes"**

### Langkah 3 – Aktifkan GitHub Pages
1. Di repo, klik tab **Settings**
2. Di sidebar kiri, klik **Pages**
3. Di bagian **Source**, pilih branch **`main`**
4. Klik **Save**
5. Tunggu 1-2 menit, lalu website aktif di:
   ```
   https://[username].github.io/sakece-web/
   ```

---

## ⚙️ Cara Ganti Nomor WhatsApp

Buka file `js/main.js`, edit baris pertama:
```js
const WA_NUMBER = '6281263631265'; // ← ganti dengan nomor kamu
```

---

## 🛒 Alur Order

1. Customer buka website → pilih produk
2. Isi jumlah & metode pembayaran
3. Klik **"Checkout via WhatsApp"**
4. Otomatis terbuka WhatsApp dengan pesan sudah terisi lengkap
5. Kamu tinggal balas & konfirmasi 🎉

---

## 🔧 Cara Edit Produk

Buka `index.html`, cari bagian `<!-- LEVEL 1 -->` atau `<!-- LEVEL 2 -->`:
```html
<h3 class="nama">Sambal Kecepe Level 1</h3>   ← ganti nama
<div class="harga">Rp 18.000</div>             ← ganti harga tampilan
```

Di fungsi checkout, ubah harga angkanya juga:
```html
onclick="checkout('Sambal Kecepe Level 1', 18000, 'qty1', 'pay1')"
                                             ↑
                                     harga dalam angka
```

---

## 📱 Fitur

- ✅ Responsive (HP & Desktop)
- ✅ Navbar sticky dengan scroll effect
- ✅ Hamburger menu mobile
- ✅ Checkout otomatis via WhatsApp
- ✅ Animasi scroll reveal
- ✅ Toast notification validasi form
- ✅ Quantity control tombol +/−
- ✅ Zero backend / zero hosting cost

---

**© 2025 SAKECE – Sambal Kecepe Asli Medan**
